package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

import processing.core.PApplet;

public class Main extends PApplet{

	private BufferedWriter writer;
	private int pantalla;
	private Socket socket;

	public static void main(String[] args) {
		PApplet.main("main.Main");
		
	}
	
	public void settings() {
		size (500,500);
	}
	
	public void setup() {
		
		new Thread(
		()->{
		try {
			ServerSocket server = new ServerSocket(5000);
			System.out.println("Esperando usuario y contrase�a"); //aqui espera hasta el cliente
			socket = server.accept(); //esperando por el metodo socket hasta que android le mande la solicitud de conexion
			System.out.println("Usuario Conectado"); 
			
			InputStream is = socket.getInputStream();
			OutputStream out = socket.getOutputStream();
			
			writer = new BufferedWriter(new OutputStreamWriter(out)); //ya esta globalizado
			BufferedReader reader = new BufferedReader (new InputStreamReader(is));
			
			while (true) { //bucle infinito de lectura
                System.out.println("Esperando datos...");
                String line = reader.readLine(); //llegan los mensajes del cliente
                System.out.println("Datos recibidos" + line);
            }
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		}
		).start();
	}
	
	public void draw() {
		background(0);
		
	}
	
}

package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;


import processing.core.PApplet;

public class Main extends PApplet{

	private BufferedWriter writer;
	private int pantalla;
	private Socket socket;
	ArrayList<Usuario> usuario; //lista de los usuarios registrados
	int pantallas = 0;

	public static void main(String[] args) {
		PApplet.main("main.Main");
		
	}
	
	public void settings() {
		size (500,500);
	}
	
	public void setup() {
		
		usuario = new ArrayList<Usuario>();
		usuario.add(new Usuario("Dan", "12345")); //nombre usuario que recibe
		
		new Thread(
		()->{
		try {
			ServerSocket server = new ServerSocket(5000);
			System.out.println("Esperando usuario y contrase�a"); //aqui espera hasta el cliente
			socket = server.accept(); //esperando por el metodo socket hasta que android le mande la solicitud de conexion
			System.out.println("Usuario Conectado"); 
			
			InputStream is = socket.getInputStream();
			OutputStream out = socket.getOutputStream();
			
			writer = new BufferedWriter(new OutputStreamWriter(out)); //ya esta globalizado
			BufferedReader reader = new BufferedReader (new InputStreamReader(is));
			
			while (true) { //bucle infinito de lectura
                System.out.println("Esperando datos...");
                String line = reader.readLine(); //llegan los mensajes del cliente
                System.out.println("Datos recibidos" + line);
                pantallas++;
                
            }
			
		} catch (IOException e) {
			
			e.printStackTrace();
			}
		}
		).start();
	}
	
	public void draw() {
		background(0);
		
		switch (pantallas) {
		case 0:
			textSize(20);
			text("Esperando datos", width/4, height/4);
			break;
		case 1:
			textSize(20);
			text("Bienvenido", width/4, height/4);
			break;
		}
	}
	
}
